const heading = document.querySelector('.list');
const harmburger = document.querySelector('.harmburger');

harmburger.addEventListener('click', ()=>{
    heading.classList.toggle('show');
    harmburger.classList.toggle('new');
});
